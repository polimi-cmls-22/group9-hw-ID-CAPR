/*
 ____  _____ _        _
| __ )| ____| |      / \
|  _ \|  _| | |     / _ \
| |_) | |___| |___ / ___ \
|____/|_____|_____/_/   \_\

http://bela.io
*/
/**
\example Analog/analog-input/render.cpp

Connecting potentiometers
-------------------------

This sketch produces a sine tone, the frequency and amplitude of which are
modulated by data received on the analog input pins. Before looping through each audio
frame, we declare a value for the `frequency` and `amplitude` of our sine tone;
we adjust these values by taking in data from analog sensors (for example potentiometers)
with `analogRead()`.

- connect a 10K pot to 3.3V and GND on its 1st and 3rd pins.
- connect the 2nd middle pin of the pot to analogIn 0.
- connect another 10K pot in the same way but with the middle pin connected to analogIn 1.

The important thing to notice is that audio is sampled twice as often as analog
data. The audio sampling rate is 44.1kHz (44100 frames per second) and the
analog sampling rate is 22.05kHz (22050 frames per second). Notice that we are
processing the analog data and updating frequency and amplitude only on every
second audio sample, since the analog sampling rate is half that of the audio.

````
if(!(n % gAudioFramesPerAnalogFrame)) {
    // Even audio samples: update frequency and amplitude from the analog inputs
    frequency = map(analogRead(context, n/gAudioFramesPerAnalogFrame, gSensorInputFrequency), 0, 1, 100, 1000);
    amplitude = analogRead(context, n/gAudioFramesPerAnalogFrame, gSensorInputAmplitude);
}
````
*/


#include <Bela.h>
#include <stdlib.h>
#include <cmath>
#include <I2c_Codec.h>
#include <array>
#include <stdio.h>
#include <libraries/OscReceiver/OscReceiver.h>
#include <libraries/OscSender/OscSender.h>

OscReceiver oscReceiver;
OscSender oscSender;
int localPort = 7562;
int remotePort = 7563;
const char* remoteIp = "192.168.6.1";
int gInputPinD = 1; // digital pin 1 - check the pin diagram in the IDE
int gInputPinZ = 0; // digital pin 1 - check the pin diagram in the IDE


int gCount = 0;
float gInterval = 0.06;

const int joystick_pinX = 0;
const int joystick_pinY = 1;


bool setup(BelaContext *context, void *userData)
{

	//OSC setup
	// Set the mode of digital pins
	pinMode(context, 0, gInputPinD, INPUT); //set input of button
	pinMode(context, 0, gInputPinZ, INPUT); //set input of z coordinate
	
	oscSender.setup(remotePort, remoteIp);

	return true;
}

// render() is called regularly at the highest priority by the audio engine.
// Input and output are given from the audio hardware and the other
// ADCs and DACs (if available). If only audio is available, numMatrixFrames
// will be 0.

void render(BelaContext *context, void *userData)
{

   	// This for() loop goes through all the samples in the block
	for (unsigned int n = 0; n < context->audioFrames; n++) {

		gCount++;
		float status=digitalRead(context, n, gInputPinD); //read the value of the button
		float pinX = map(analogRead(context, n%4, joystick_pinX),0,0.8,-1.0,1.0);
		float pinY = analogRead(context, n%4, joystick_pinY);
		float pinZ=digitalRead(context, n, gInputPinZ); //read the value of the button
	
		
		rt_printf("Joy x: %f\n", pinX);
	
		
		
		if(gCount % (int)(context->audioSampleRate*gInterval) == 0) {
            oscSender.newMessage("/movement/xPosition");
            oscSender.add(pinX);
            oscSender.send();
            
            oscSender.newMessage("/movement/yPosition");
            oscSender.add(pinY);
            oscSender.send();
            
            oscSender.newMessage("/movement/zPosition");
            oscSender.add(pinZ);
            oscSender.send();
            
            oscSender.newMessage("/movement/statusPosition");
            oscSender.add(status);
            oscSender.send();
        }
    }
}

// cleanup() is called once at the end, after the audio has stopped.
// Release any resources that were allocated in setup().

void cleanup(BelaContext *context, void *userData)
{
	
}

